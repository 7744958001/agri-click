package com.agritech.agritech_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgritechAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
